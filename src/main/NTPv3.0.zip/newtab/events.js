document.getElementById('settings-button').addEventListener('click', function() {
    window.location.href = '../settings/settings.html';
});